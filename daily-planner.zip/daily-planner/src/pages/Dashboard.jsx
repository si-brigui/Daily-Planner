import { useMemo, useState } from "react";
import TaskInput from "../components/TaskInput.jsx";
import TaskCard from "../components/TaskCard.jsx";
import AiSummary from "../components/AiSummary.jsx";
import TimeGrid from "../components/TimeGrid.jsx";
import useLocalStorage from "../hooks/useLocalStorage.js";

export default function Dashboard() {
  const [tasks, setTasks] = useLocalStorage("tasks", []);
  const [filter, setFilter] = useState("all");

  const visible = useMemo(() => {
    if (filter === "done") return tasks.filter((t) => t.done);
    if (filter === "open") return tasks.filter((t) => !t.done);
    return tasks;
  }, [tasks, filter]);

  const addTask = (title) => {
    const t = title.trim();
    if (!t) return;
    setTasks((prev) => [
      {
        id: crypto.randomUUID?.() ?? String(Date.now()),
        title: t,
        done: false,
      },
      ...prev,
    ]);
  };

  const toggleTask = (id) =>
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    );

  const editTask = (id, title) =>
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, title } : t)));

  const delTask = (id) => setTasks((prev) => prev.filter((t) => t.id !== id));
  const clearDone = () => setTasks((prev) => prev.filter((t) => !t.done));

  return (
    <div className="space-y-6">
      {/* Task Input Section */}
      <div className="border rounded-lg p-4 bg-white shadow-md">
        <TaskInput onAdd={addTask} />
      </div>

      {/* Filter Buttons */}
      <div className="flex gap-2 justify-between items-center mb-6">
        {["all", "open", "done"].map((f) => (
          <button
            key={f}
            className={`btn btn-chip ${
              filter === f ? "chip-active" : ""
            } rounded-full border border-blue-500 px-4 py-2 text-blue-500 hover:bg-blue-200 transition-colors duration-300`}
            onClick={() => setFilter(f)}
          >
            {f}
          </button>
        ))}
        <button
          className="btn link-danger rounded-full border border-red-500 px-4 py-2 text-red-500 hover:bg-red-200 transition-colors duration-300"
          onClick={clearDone}
          disabled={!tasks.some((t) => t.done)}
        >
          Clear completed
        </button>
      </div>

      {/* Tasks Section */}
      <section className="border rounded-lg p-4 bg-white shadow-md">
        <h2 className="section-title text-xl font-semibold text-black">
          Tasks
        </h2>
        {visible.length === 0 ? (
          <p className="muted">No tasks yet. Add your first one above!</p>
        ) : (
          <div className="list space-y-4">
            {visible.map((t) => (
              <TaskCard
                key={t.id}
                task={t}
                onToggle={() => toggleTask(t.id)}
                onDelete={() => delTask(t.id)}
                onEdit={(title) => editTask(t.id, title)}
              />
            ))}
          </div>
        )}
      </section>

      {/* Time Breakdown */}
      <div className="border rounded-lg p-4 bg-white shadow-md">
        <TimeGrid tasks={tasks} />
      </div>

      {/* AI Summary Section */}
      <div className="border rounded-lg p-4 bg-white shadow-md">
        <AiSummary tasks={tasks} />
      </div>
    </div>
  );
}
