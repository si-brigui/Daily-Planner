import React from "react";
import Dashboard from "./pages/Dashboard.jsx";
import "./index.css"; // Import TailwindCSS and custom styles

export default function App() {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-br from-blue-400 to-blue-600 py-8 md:py-0">
      {/* Main Container */}
      <div className="max-w-2xl w-full bg-white shadow-lg rounded-3xl p-8">
        <header className="text-center pb-6">
          <h1 className="text-5xl font-bold text-teal-600 tracking-wide">
            Daily Planner
          </h1>
        </header>
        {/* Main Content */}
        <main className="px-6">
          <Dashboard /> {/* Your Dashboard Component */}
        </main>
      </div>
    </div>
  );
}
