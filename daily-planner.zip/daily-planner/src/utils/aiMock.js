export function getMockSummary(tasks) {
  const total = tasks.length;
  const done = tasks.filter((t) => t.done).length;
  const open = total - done;

  if (total === 0)
    return "You have no tasks yet. Add a few goals to get started!";
  if (done === total)
    return "All tasks completed — great job! Consider adding tomorrow’s priorities.";

  const top = tasks
    .filter((t) => !t.done)
    .slice(0, 3)
    .map((t, i) => `${i + 1}. ${t.title}`)
    .join(" ");
  return `Today's progress: ${done}/${total} done. Focus on ${open} open task(s). Next up: ${top}`;
}
