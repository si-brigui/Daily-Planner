import { useMemo } from "react";
import { getMockSummary } from "../utils/aiMock.js";

export default function AiSummary({ tasks }) {
  const summary = useMemo(() => getMockSummary(tasks), [tasks]);

  return (
    <section className="card">
      <div className="row spread">
        <h2 className="section-title"> Summary</h2>
      </div>
      <p className="muted">{summary}</p>
    </section>
  );
}
