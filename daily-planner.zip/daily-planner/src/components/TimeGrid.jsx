import React from "react";

export default function TimeGrid({ tasks }) {
  const totalTasks = tasks.length;
  const doneTasks = tasks.filter((task) => task.done).length;

  return (
    <section className="card">
      <h2 className="section-title">Time Breakdown</h2>
      <div>
        <p>
          Total Tasks: {totalTasks} | Completed: {doneTasks}
        </p>
      </div>
    </section>
  );
}
