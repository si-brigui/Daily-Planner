import { useState } from "react";

export default function TaskInput({ onAdd }) {
  const [value, setValue] = useState("");

  const submit = (e) => {
    e.preventDefault();
    onAdd?.(value); // Add the task
    setValue(""); // Reset the input field
  };

  return (
    <form className="flex items-center gap-2" onSubmit={submit}>
      <input
        className="input flex-1 p-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Add a task..."
        value={value}
        onChange={(e) => setValue(e.target.value)} // Update the input value
      />
      <button
        type="submit"
        className="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-300"
      >
        Add
      </button>
    </form>
  );
}
