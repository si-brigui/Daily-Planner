import { useState } from "react";

export default function TaskCard({ task, onToggle, onDelete, onEdit }) {
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(task.title);

  const save = () => {
    const t = title.trim();
    if (t && t !== task.title) {
      onEdit?.(t); // Save the edited task title
    }
    setEditing(false);
  };

  return (
    <div className="task flex items-center justify-between gap-4 p-4 border rounded-lg bg-gray-50 shadow-sm">
      <input
        type="checkbox"
        checked={task.done}
        onChange={onToggle}
        className="checkbox"
        aria-label="Mark done"
      />
      <div className="task-body flex-1">
        {editing ? (
          <input
            autoFocus
            className="input w-full"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && save()}
            onBlur={save}
          />
        ) : (
          <div
            className={`task-title ${
              task.done ? "line-through text-gray-400" : ""
            }`}
            onDoubleClick={() => setEditing(true)}
            title="Double-click to edit"
          >
            {task.title}
          </div>
        )}
      </div>

      <div className="task-actions flex gap-2">
        {!editing && (
          <button
            className="link text-blue-600 hover:underline"
            onClick={() => setEditing(true)}
          >
            Edit
          </button>
        )}
        <button
          className="link text-red-600 hover:underline"
          onClick={onDelete}
        >
          Delete
        </button>
      </div>
    </div>
  );
}
